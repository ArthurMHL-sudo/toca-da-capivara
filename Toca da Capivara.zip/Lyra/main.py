import glob
import os
import re
import shutil
import tempfile
import threading
import uuid
from urllib.parse import urlparse

import yt_dlp
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from starlette.background import BackgroundTask

app = FastAPI(title="Toca da Capivara")
TMP = tempfile.mkdtemp(prefix="toca_")
JOBS: dict = {}

if not shutil.which("ffmpeg"):
    print("AVISO: ffmpeg nao encontrado. O YouTube precisa dele para a maioria dos videos (winget install ffmpeg).")
if not shutil.which("deno"):
    print("AVISO: deno nao encontrado. O yt-dlp pode precisar dele para o YouTube (winget install DenoLand.Deno).")


class Interrupted(getattr(getattr(yt_dlp, "utils", None), "DownloadCancelled", Exception)):
    """Lançada de dentro do hook para parar a descarga (pausa ou cancelamento)."""


BROWSERS = {"firefox", "edge", "chrome", "brave", "chromium", "opera", "vivaldi"}


def check_browser(browser: str) -> str:
    browser = (browser or "").lower()
    if browser and browser not in BROWSERS:
        raise HTTPException(400, "Navegador não suportado.")
    return browser


IMPERSONATE_SITES = ("tiktok.com", "instagram.com")


def impersonate_opt(url: str):
    """TikTok e Instagram só respondem bem a um 'navegador a sério'. Precisa do pacote curl-cffi."""
    try:
        import curl_cffi  # noqa: F401
        from yt_dlp.networking.impersonate import ImpersonateTarget
        host = urlparse(url or "").hostname or ""
        if any(host == d or host.endswith("." + d) for d in IMPERSONATE_SITES):
            return ImpersonateTarget.from_str("chrome")
    except Exception:
        pass
    return None


def explain(e: Exception) -> str:
    """Mensagem de erro curta e útil: tira o ruído do yt-dlp e acrescenta uma dica."""
    msg = re.sub(r"\x1b\[[0-9;]*m", "", str(e)).strip()
    msg = re.sub(r"^ERROR:\s*", "", msg)
    msg = re.split(r";\s*please report this issue", msg)[0][:220]
    low = msg.lower()
    if "unexpected response from webpage" in low or "unable to extract" in low or "failed to parse" in low:
        msg += (" | Dica: o site mudou ou está a bloquear. Fecha e abre o iniciar.bat (atualiza o yt-dlp). "
                "Se continuar, escolhe os cookies do Firefox em 'Opções avançadas'.")
    elif "403" in msg or "sign in to confirm" in low:
        msg += (" | Dica: atualiza o yt-dlp (o iniciar.bat faz isso) ou abre 'Opções avançadas' "
                "e escolhe os cookies do Firefox, com sessão iniciada no YouTube.")
    elif "login" in low or "rate-limit" in low or "empty media response" in low or "private" in low:
        msg += (" | Dica: este site pede sessão iniciada. Em 'Opções avançadas' escolhe o navegador "
                "onde tens a conta aberta (o Firefox funciona melhor).")
    elif "cookie" in low:
        msg += " | Dica: fecha o navegador escolhido ou usa o Firefox."
    return msg


def base_opts(browser: str = "", url: str = "") -> dict:
    """Cookies (ajudam contra o erro 403 do YouTube): cookies.txt ao lado do main.py,
    senão o navegador escolhido na página, senão a variável ABISMO_BROWSER."""
    o = {"quiet": True, "no_color": True, "noplaylist": True, "playlistend": 1}
    cookies = os.path.join(os.path.dirname(os.path.abspath(__file__)), "cookies.txt")
    if os.path.exists(cookies):
        o["cookiefile"] = cookies
    elif browser:
        o["cookiesfrombrowser"] = (browser,)
    elif os.environ.get("ABISMO_BROWSER"):
        o["cookiesfrombrowser"] = (os.environ["ABISMO_BROWSER"],)
    imp = impersonate_opt(url)
    if imp is not None:
        o["impersonate"] = imp
    return o


def check_url(url: str) -> str:
    """Aceita texto com um link lá dentro (ex.: 'Vê isto: https://...') e devolve só o link."""
    m = re.search(r"https?://[^\s<>\"']+", url or "")
    if not m:
        raise HTTPException(400, "Cola um link que comece por http:// ou https://")
    return m.group(0).rstrip(".,;:!?)]}")  # tira pontuação do fim, ex.: "(link: https://...)."


def pick(data: dict):
    """Carrosséis do Instagram e playlists: usa só o primeiro item."""
    if data.get("_type") == "playlist" or data.get("entries") is not None:
        entries = [e for e in (data.get("entries") or []) if e]
        if not entries:
            raise RuntimeError("Não encontrei nenhum vídeo neste link.")
        return entries[0], True
    return data, False


def get_job(job_id: str) -> dict:
    job = JOBS.get(job_id)
    if not job:
        raise HTTPException(404, "Descarga não encontrada.")
    return job


def discard(job_id: str, job: dict):
    """Apaga tudo o que foi descarregado (incluindo partes) e marca como cancelado."""
    for f in glob.glob(os.path.join(TMP, f"{job_id}.*")):
        try:
            os.remove(f)
        except OSError:
            pass
    job["path"] = None
    job["speed"] = job["eta"] = None
    job["state"] = "cancelled"


@app.get("/api/info")
def info(url: str, browser: str = ""):
    url = check_url(url)
    browser = check_browser(browser)
    try:
        with yt_dlp.YoutubeDL(base_opts(browser, url)) as ydl:
            data = ydl.extract_info(url, download=False)
        data, multiple = pick(data)
    except Exception as e:
        raise HTTPException(422, f"Não foi possível ler este link: {explain(e)}")
    heights = sorted({f["height"] for f in data.get("formats", []) if f.get("height")}, reverse=True)
    return {
        "title": data.get("title"),
        "thumbnail": data.get("thumbnail"),
        "duration": data.get("duration"),
        "uploader": data.get("uploader") or data.get("channel"),
        "site": data.get("extractor_key"),
        "multiple": multiple,
        "heights": heights,
    }


def run_job(job_id: str, url: str, quality: str):
    job = JOBS[job_id]
    has_ffmpeg = shutil.which("ffmpeg") is not None
    # com ffmpeg: vídeo + áudio são 2 ficheiros; sem ffmpeg: ficheiro único
    expected = 1 if (quality == "audio" or not has_ffmpeg) else 2

    def hook(d):
        if job["want"]:  # pausa ou cancelamento pedidos: pára já
            raise Interrupted(job["want"])
        if d["status"] == "downloading":
            total = d.get("total_bytes") or d.get("total_bytes_estimate") or 0
            frac = (d.get("downloaded_bytes") or 0) / total if total else 0
            pct = (job["files_done"] + frac) / expected * 100
            job["percent"] = max(job["percent"], min(pct, 99))  # nunca recua
            job["speed"] = d.get("speed")
            job["eta"] = d.get("eta")
            job["state"] = "downloading"
        elif d["status"] == "finished":
            job["files_done"] += 1
            job["state"] = "processing"

    def pp_hook(d):
        if d["status"] == "started":
            job["state"] = "processing"

    opts = {
        **base_opts(job["browser"], url),
        "outtmpl": os.path.join(TMP, f"{job_id}.%(ext)s"),  # mesmo nome => a retoma continua a parte guardada
        "merge_output_format": "mp4",
        "progress_hooks": [hook],
        "postprocessor_hooks": [pp_hook],
    }
    if quality == "audio":
        if has_ffmpeg:
            opts["format"] = "bestaudio/best"
            opts["postprocessors"] = [{"key": "FFmpegExtractAudio", "preferredcodec": "mp3"}]
        else:
            opts["format"] = "bestaudio[ext=m4a]/bestaudio/best"  # sem ffmpeg fica em m4a
    elif quality.isdigit():
        h = int(quality)
        if has_ffmpeg:
            opts["format"] = f"bestvideo[height<={h}]+bestaudio/best[height<={h}]/best"
        else:
            opts["format"] = f"best[height<={h}][ext=mp4]/best[height<={h}]/best"
    else:
        opts["format"] = "bestvideo+bestaudio/best" if has_ffmpeg else "best[ext=mp4]/best"

    try:
        with yt_dlp.YoutubeDL(opts) as ydl:
            data, _ = pick(ydl.extract_info(url, download=True))
        if job["want"] == "stop":  # cancelado durante a fase de junção
            discard(job_id, job)
            return
        path = ((data.get("requested_downloads") or [{}])[0]).get("filepath")
        if not path or not os.path.exists(path):
            files = glob.glob(os.path.join(TMP, f"{job_id}.*"))
            if not files:
                raise RuntimeError("Ficheiro não encontrado após a descarga.")
            path = max(files, key=os.path.getsize)  # o final é o maior
        safe = re.sub(r'[\\/:*?"<>|]+', "", data.get("title") or data.get("id") or "video")[:80].strip() or "video"
        job["want"] = None
        job["path"] = path
        job["filename"] = safe + os.path.splitext(path)[1]
        job["percent"] = 100
        job["state"] = "done"
    except Exception as e:
        want = job["want"]
        if want == "pause":
            job["speed"] = job["eta"] = None
            job["state"] = "paused"  # ficheiros parciais ficam guardados
        elif want == "stop":
            discard(job_id, job)
        else:
            msg = explain(e)
            if "Requested format is not available" in msg and not has_ffmpeg:
                msg = ("Este video so tem video e audio em ficheiros separados e o ffmpeg nao esta instalado. "
                       "Instala-o com: winget install ffmpeg. Depois fecha o terminal, abre outro e arranca a Toca da Capivara outra vez.")
            job["error"] = f"Falha na descarga: {msg}"
            job["state"] = "error"


def launch(job_id: str):
    job = JOBS[job_id]
    threading.Thread(target=run_job, args=(job_id, job["url"], job["quality"]), daemon=True).start()


@app.post("/api/start")
def start(url: str, quality: str = "best", browser: str = ""):
    url = check_url(url)
    browser = check_browser(browser)
    job_id = uuid.uuid4().hex
    JOBS[job_id] = {"state": "starting", "percent": 0, "speed": None, "eta": None, "files_done": 0,
                    "error": None, "path": None, "filename": None, "want": None,
                    "url": url, "quality": quality, "browser": browser}
    launch(job_id)
    return {"job": job_id}


@app.post("/api/pause/{job_id}")
def pause(job_id: str):
    job = get_job(job_id)
    if job["state"] in ("starting", "downloading"):
        job["want"] = "pause"
        return {"ok": True}
    if job["state"] == "paused":
        return {"ok": True}
    raise HTTPException(409, "Não é possível pausar nesta fase.")


@app.post("/api/resume/{job_id}")
def resume(job_id: str):
    job = get_job(job_id)
    if job["state"] != "paused":
        raise HTTPException(409, "A descarga não está em pausa.")
    job["want"] = None
    job["files_done"] = 0  # o yt-dlp salta os ficheiros já completos e conta-os de novo
    job["state"] = "starting"
    launch(job_id)
    return {"ok": True}


@app.post("/api/cancel/{job_id}")
def cancel(job_id: str):
    job = get_job(job_id)
    if job["state"] in ("paused", "done"):
        discard(job_id, job)
    elif job["state"] in ("starting", "downloading", "processing"):
        job["want"] = "stop"
    return {"ok": True}


@app.get("/api/progress/{job_id}")
def progress(job_id: str):
    job = get_job(job_id)
    return {k: job[k] for k in ("state", "percent", "speed", "eta", "error")}


@app.get("/api/file/{job_id}")
def file(job_id: str):
    job = JOBS.get(job_id)
    if not job or job["state"] != "done":
        raise HTTPException(409, "O ficheiro ainda não está pronto.")

    def cleanup():  # apaga do servidor tudo o que sobrou desta descarga
        try:
            for f in glob.glob(os.path.join(TMP, f"{job_id}.*")):
                try:
                    os.remove(f)
                except OSError:
                    pass
        finally:
            JOBS.pop(job_id, None)

    return FileResponse(job["path"], filename=job["filename"], background=BackgroundTask(cleanup))


BASE = os.path.dirname(os.path.abspath(__file__))


@app.get("/")
def home():
    return FileResponse(os.path.join(BASE, "index.html"))


@app.get("/style.css")
def style():
    # no-cache: alterações ao CSS aparecem logo ao recarregar a página
    return FileResponse(os.path.join(BASE, "style.css"), media_type="text/css",
                        headers={"Cache-Control": "no-cache"})
