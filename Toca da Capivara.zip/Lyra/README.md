# Toca da Capivara

1. Instala o Python 3.12 e corre uma vez:  python -m pip install -r requirements.txt
2. Para 1080p+ e MP3:  winget install ffmpeg   (e para o YouTube:  winget install DenoLand.Deno)
3. Faz duplo clique em iniciar.bat. Abre o Chrome/Edge em http://127.0.0.1:8765

Sites: YouTube, Instagram, TikTok e outros que o yt-dlp suporta. O Instagram costuma pedir login (usa as Opções avançadas).
Se o YouTube der erro 403: "Opções avançadas" na página > Firefox (com sessão iniciada no YouTube).
Sem ffmpeg a Toca da Capivara descarrega um ficheiro unico (normalmente ate 720p).

Ficheiros: main.py (servidor), index.html (página), style.css (estilo), iniciar.bat.

TikTok/Instagram: o iniciar.bat instala o curl-cffi e a versao mais recente do yt-dlp (os sites mudam muitas vezes).
